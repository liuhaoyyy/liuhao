"""
推理脚本：加载训练好的HAT-Transformer模型进行中英双向翻译
支持：命令行交互、文件批量翻译、API服务
"""
import os
import sys
import json
import argparse
import time
import re

import torch

PROJ_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJ_DIR)

from models.hat_transformer import HATTransformer
from utils.tokenizer import BilingualTokenizer


class Translator:
    """翻译引擎"""

    def __init__(self, checkpoint_path, tokenizer_path=None, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        # 加载检查点
        checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        self.config = checkpoint["config"]

        # 加载分词器
        if tokenizer_path:
            self.tokenizer = BilingualTokenizer(tokenizer_path)
        else:
            tokenizer_path = os.path.join(PROJ_DIR, "models", "bpe_tokenizer.model")
            if os.path.exists(tokenizer_path):
                self.tokenizer = BilingualTokenizer(tokenizer_path)
            else:
                raise FileNotFoundError(
                    f"Tokenizer not found at {tokenizer_path}. "
                    "Please run train_tokenizer first or specify --tokenizer_path."
                )

        self.vocab_size = self.tokenizer.vocab_size

        # 构建模型
        self.model = HATTransformer(
            src_vocab_size=self.vocab_size,
            tgt_vocab_size=self.vocab_size,
            d_model=self.config.get("d_model", 512),
            n_heads=self.config.get("n_heads", 8),
            n_encoder_layers=self.config.get("n_encoder_layers", 6),
            n_decoder_layers=self.config.get("n_decoder_layers", 6),
            d_ff=self.config.get("d_ff", 2048),
            dropout=0.0,  # 推理时关闭dropout
            local_ratio=self.config.get("local_ratio", 0.5),
            window_size=self.config.get("window_size", 32),
            max_seq_len=self.config.get("max_seq_len", 128),
            pad_idx=self.tokenizer.special_tokens["PAD"],
        )

        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.model = self.model.to(self.device)
        self.model.eval()

        # 常用特殊token
        self.bos_id = self.tokenizer.special_tokens["BOS"]
        self.eos_id = self.tokenizer.special_tokens["EOS"]
        self.pad_id = self.tokenizer.special_tokens["PAD"]

        print(f"Model loaded successfully.")
        print(f"  Parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        print(f"  Checkpoint step: {checkpoint.get('global_step', 'N/A')}")
        print(f"  Best valid loss: {checkpoint.get('best_valid_loss', 'N/A'):.4f}")

    @torch.no_grad()
    def translate(
        self,
        text,
        beam_size=5,
        max_len=128,
        return_attention=False,
    ):
        """
        翻译文本

        Args:
            text: 输入文本
            beam_size: 束搜索宽度（1=贪心）
            max_len: 最大生成长度
            return_attention: 是否返回注意力权重

        Returns:
            翻译结果字符串（或 (结果, 注意力权重) 元组）
        """
        # 检测输入语言
        is_chinese = bool(re.search(r'[一-鿿]', text))

        # 编码
        src_ids = self.tokenizer.encode(text, max_len=max_len, add_bos=True, add_eos=True)
        src_tensor = torch.tensor([src_ids], dtype=torch.long, device=self.device)
        src_mask = (src_tensor != self.pad_id).bool().unsqueeze(1).unsqueeze(2)

        # 编码器
        enc_out = self.model.encode(src_tensor, src_mask)

        # 解码
        if beam_size == 1:
            generated = self._greedy_decode(enc_out, src_mask, max_len)
        else:
            generated = self._beam_search_decode(enc_out, src_mask, beam_size, max_len)

        # 解码为文本
        result = self.tokenizer.decode(generated[0].tolist(), skip_special=True)
        return result

    def _greedy_decode(self, enc_out, src_mask, max_len):
        """贪心解码"""
        batch = enc_out.shape[0]
        generated = torch.full((batch, 1), self.bos_id, dtype=torch.long, device=self.device)

        for _ in range(max_len):
            tgt_mask = self.model._causal_mask(generated.shape[1], self.device)
            logits = self.model.decode(generated, enc_out, src_mask, tgt_mask)
            next_token = logits[:, -1:, :].argmax(dim=-1)
            generated = torch.cat([generated, next_token], dim=1)

            if (next_token == self.eos_id).all():
                break

        return generated

    def _beam_search_decode(self, enc_out, src_mask, beam_size, max_len):
        """束搜索解码"""
        batch = enc_out.shape[0]
        device = self.device
        d_model = enc_out.shape[-1]

        # 扩展编码器输出
        enc_out = enc_out.unsqueeze(1).expand(-1, beam_size, -1, -1).reshape(batch * beam_size, -1, d_model)
        if src_mask is not None:
            src_mask = src_mask.unsqueeze(1).expand(-1, beam_size, -1, -1, -1).reshape(batch * beam_size, 1, 1, -1)

        # 初始化beam
        scores = torch.zeros(batch, beam_size, device=device)
        scores[:, 1:] = -1e9
        sequences = torch.full((batch, beam_size, 1), self.bos_id, dtype=torch.long, device=device)
        done = torch.zeros(batch, beam_size, dtype=torch.bool, device=device)

        for step in range(max_len):
            curr_seq = sequences.view(batch * beam_size, -1)
            tgt_mask = self.model._causal_mask(curr_seq.shape[1], device)

            logits = self.model.decode(curr_seq, enc_out, src_mask, tgt_mask)
            log_probs = torch.nn.functional.log_softmax(logits[:, -1, :], dim=-1)
            log_probs = log_probs.view(batch, beam_size, -1)

            # 累积分数
            log_probs = log_probs + scores.unsqueeze(-1)

            if done.any():
                log_probs[done] = -1e9

            # 第一步只在第一个beam扩展
            if step == 0:
                log_probs = log_probs[:, 0:1, :]

            flat_scores, flat_idx = log_probs.view(batch, -1).topk(beam_size, dim=-1)
            scores = flat_scores
            beam_idx = flat_idx // log_probs.shape[-1]
            token_idx = flat_idx % log_probs.shape[-1]

            # 更新序列
            new_sequences = torch.zeros(batch, beam_size, step + 2, dtype=torch.long, device=device)
            for b in range(batch):
                for k in range(beam_size):
                    prev = beam_idx[b, k]
                    new_sequences[b, k, :step + 1] = sequences[b, prev, :]
                    new_sequences[b, k, step + 1] = token_idx[b, k]

            sequences = new_sequences

            # 检查EOS
            for b in range(batch):
                for k in range(beam_size):
                    if token_idx[b, k] == self.eos_id:
                        done[b, k] = True

            if done.all():
                break

        return sequences[:, 0, :]

    def translate_batch(self, texts, beam_size=3, max_len=128):
        """批量翻译"""
        results = []
        for text in texts:
            try:
                result = self.translate(text, beam_size=beam_size, max_len=max_len)
                results.append(result)
            except Exception as e:
                results.append(f"[ERROR: {str(e)}]")
        return results

    def translate_file(self, input_path, output_path, beam_size=3):
        """翻译文件（每行一个句子）"""
        with open(input_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]

        print(f"Translating {len(lines)} lines...")
        start = time.time()

        results = self.translate_batch(lines, beam_size=beam_size)

        with open(output_path, "w", encoding="utf-8") as f:
            for line, result in zip(lines, results):
                f.write(f"{result}\n")

        elapsed = time.time() - start
        print(f"Done. {len(lines)} lines in {elapsed:.1f}s ({len(lines) / elapsed:.1f} lines/s)")
        return results


def interactive_mode(translator, beam_size=5):
    """交互式翻译模式"""
    print("\n" + "=" * 60)
    print("  奶龙卡通中英文翻译系统 - 交互模式")
    print("  输入文本后按回车翻译，输入 /quit 退出")
    print("  输入 /beam N 设置束搜索宽度")
    print("  " + "=" * 60 + "\n")

    while True:
        try:
            text = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not text:
            continue

        if text.lower() in ("/quit", "/exit", "/q"):
            print("Goodbye!")
            break

        if text.startswith("/beam "):
            try:
                beam_size = int(text.split()[1])
                beam_size = max(1, min(beam_size, 20))
                print(f"Beam size set to {beam_size}")
            except ValueError:
                print("Usage: /beam <number>")
            continue

        start = time.time()
        result = translator.translate(text, beam_size=beam_size)
        elapsed = time.time() * 1000

        is_zh = bool(re.search(r'[一-鿿]', text))
        src_label = "ZH" if is_zh else "EN"
        tgt_label = "EN" if is_zh else "ZH"

        print(f"  [{src_label}->{tgt_label}] {result}")
        print(f"  ({elapsed:.0f}ms)\n")


def main():
    parser = argparse.ArgumentParser(description="奶龙卡通中英文翻译系统 - 推理")
    parser.add_argument("--checkpoint", type=str,
                        default=os.path.join(PROJ_DIR, "results", "checkpoint_epoch30_best.pt"),
                        help="模型检查点路径")
    parser.add_argument("--tokenizer", type=str,
                        default=os.path.join(PROJ_DIR, "models", "bpe_tokenizer.model"),
                        help="分词器路径")
    parser.add_argument("--text", type=str, default=None, help="直接翻译文本")
    parser.add_argument("--input", type=str, default=None, help="输入文件路径")
    parser.add_argument("--output", type=str, default=None, help="输出文件路径")
    parser.add_argument("--beam", type=int, default=5, help="束搜索宽度")
    parser.add_argument("--device", type=str, default=None, help="设备 (cuda/cpu)")
    parser.add_argument("--interactive", action="store_true", default=True,
                        help="交互模式（默认）")

    args = parser.parse_args()

    # 查找检查点
    if not os.path.exists(args.checkpoint):
        # 尝试查找任意检查点
        results_dir = os.path.join(PROJ_DIR, "results")
        if os.path.exists(results_dir):
            ckpts = [f for f in os.listdir(results_dir) if f.endswith(".pt")]
            if ckpts:
                ckpts.sort()
                args.checkpoint = os.path.join(results_dir, ckpts[-1])
                print(f"Using checkpoint: {args.checkpoint}")
            else:
                print("No checkpoint found. Please train the model first.")
                print("Run: python train.py")
                sys.exit(1)
        else:
            print("No checkpoint found. Please train the model first.")
            print("Run: python train.py")
            sys.exit(1)

    # 初始化翻译器
    translator = Translator(
        checkpoint_path=args.checkpoint,
        tokenizer_path=args.tokenizer,
        device=args.device,
    )

    # 单句翻译
    if args.text:
        result = translator.translate(args.text, beam_size=args.beam)
        print(f"Input:  {args.text}")
        print(f"Output: {result}")
        return

    # 文件翻译
    if args.input:
        output = args.output or args.input + ".translated"
        translator.translate_file(args.input, output, beam_size=args.beam)
        return

    # 交互模式
    if args.interactive:
        interactive_mode(translator, beam_size=args.beam)


if __name__ == "__main__":
    main()
