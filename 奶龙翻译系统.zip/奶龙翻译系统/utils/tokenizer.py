"""
BPE 分词器：使用SentencePiece训练中英文联合词表
"""
import os
import json
import sentencepiece as spm


class BilingualTokenizer:
    """中英双语分词器"""

    def __init__(self, model_path=None):
        self.sp = None
        self.special_tokens = {
            "PAD": 0,
            "BOS": 1,
            "EOS": 2,
            "UNK": 3,
        }
        self.vocab_size = 0
        if model_path and os.path.exists(model_path):
            self.load(model_path)

    def train(self, text_files, model_prefix, vocab_size=32000, character_coverage=0.9995):
        """
        训练SentencePiece模型
        text_files: 包含训练文本的文件列表（英文+中文）
        """
        # 合并所有文本到一个临时文件
        combined = model_prefix + "_combined.txt"
        with open(combined, "w", encoding="utf-8") as outf:
            for f in text_files:
                with open(f, "r", encoding="utf-8") as inf:
                    for line in inf:
                        outf.write(line.strip() + "\n")

        spm.SentencePieceTrainer.train(
            input=combined,
            model_prefix=model_prefix,
            vocab_size=vocab_size,
            character_coverage=character_coverage,
            model_type="bpe",
            max_sentence_length=4192,
            pad_id=0,
            bos_id=1,
            eos_id=2,
            unk_id=3,
            pad_piece="[PAD]",
            bos_piece="[BOS]",
            eos_piece="[EOS]",
            unk_piece="[UNK]",
            user_defined_symbols=["[EN]", "[ZH]"],
            num_threads=4,
        )

        # 清理
        os.remove(combined)

        self.load(model_prefix + ".model")
        print(f"Tokenizer trained. Vocab size: {self.vocab_size}")
        return model_prefix + ".model"

    def load(self, model_path):
        self.sp = spm.SentencePieceProcessor()
        self.sp.load(model_path)
        self.vocab_size = self.sp.get_piece_size()

    def encode(self, text, max_len=None, add_bos=True, add_eos=True):
        """编码单个文本"""
        ids = self.sp.encode_as_ids(text)
        if add_bos:
            ids = [self.special_tokens["BOS"]] + ids
        if add_eos:
            ids = ids + [self.special_tokens["EOS"]]
        if max_len is not None:
            ids = ids[:max_len]
        return ids

    def decode(self, ids, skip_special=True):
        """解码id序列为文本"""
        # 去除特殊token
        if skip_special:
            ids = [i for i in ids if i not in self.special_tokens.values()]
        return self.sp.decode_ids(ids)

    def batch_encode(self, texts, max_len=None, padding=True):
        """批量编码"""
        encoded = []
        for text in texts:
            ids = self.encode(text, max_len, add_bos=True, add_eos=True)
            encoded.append(ids)

        if padding:
            max_l = max(len(ids) for ids in encoded)
            padded = []
            masks = []
            for ids in encoded:
                pad_len = max_l - len(ids)
                padded.append(ids + [self.special_tokens["PAD"]] * pad_len)
                masks.append([1] * len(ids) + [0] * pad_len)
            return padded, masks

        return encoded, None

    def save_vocab(self, path):
        """保存词表映射"""
        vocab = {}
        for i in range(self.vocab_size):
            vocab[i] = self.sp.id_to_piece(i)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(vocab, f, ensure_ascii=False, indent=2)


def train_tokenizer(data_dir, model_dir, vocab_size=32000):
    """训练分词器"""
    train_en = os.path.join(data_dir, "processed", "train.en")
    train_zh = os.path.join(data_dir, "processed", "train.zh")

    os.makedirs(model_dir, exist_ok=True)
    model_prefix = os.path.join(model_dir, "bpe_tokenizer")

    tokenizer = BilingualTokenizer()
    model_path = tokenizer.train(
        text_files=[train_en, train_zh],
        model_prefix=model_prefix,
        vocab_size=vocab_size,
    )

    # 保存词表
    tokenizer.save_vocab(os.path.join(model_dir, "vocab.json"))
    print(f"Tokenizer and vocab saved to {model_dir}")

    return model_path


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="U:/实践/深度学习/奶龙翻译系统/data")
    parser.add_argument("--model_dir", type=str, default="U:/实践/深度学习/奶龙翻译系统/models")
    parser.add_argument("--vocab_size", type=int, default=32000)
    args = parser.parse_args()

    # 需要先运行 prepare_dataset.py 生成数据
    train_tokenizer(args.data_dir, args.model_dir, args.vocab_size)
