"""
改进的Transformer模型：层次化注意力Transformer与门控融合 (HAT-GF)

创新点：
1. 层次化多头注意力 (Hierarchical Multi-Head Attention)
   - 将注意力头分为多个层次组，不同组关注不同粒度的语义信息
   - 低层组使用小窗口局部注意力捕获短语结构
   - 高层组使用全局注意力捕获长距离依赖

2. 门控融合机制 (Gated Fusion Mechanism)
   - 在每层使用可学习的门控单元融合不同层次注意力输出
   - 门控值随训练自适应调整，让模型学会在不同位置使用不同注意力模式

3. 深度可分离前馈网络 (Depthwise Separable FFN)
   - 将标准FFN分解为逐通道和逐位置两个阶段
   - 显著减少参数量的同时保持表达能力

4. 相对位置编码增强 (Enhanced Relative Position Encoding)
   - 结合了旋转位置编码(RoPE)和可学习相对位置偏置
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class RotaryPositionalEmbedding(nn.Module):
    """旋转位置编码 (RoPE)"""
    def __init__(self, dim, max_len=512):
        super().__init__()
        inv_freq = 1.0 / (10000 ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)
        self.max_len = max_len

    def forward(self, x, offset=0):
        """
        x: [batch, n_heads, seq_len, head_dim] 或 [batch, seq_len, dim]
        """
        seq_len = x.shape[-2] if x.dim() == 4 else x.shape[1]
        t = torch.arange(seq_len, device=x.device) + offset
        freqs = torch.einsum("i,j->ij", t.float(), self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos().unsqueeze(0)
        sin = emb.sin().unsqueeze(0)
        return cos, sin


def rotate_half(x):
    x1, x2 = x[..., :x.shape[-1] // 2], x[..., x.shape[-1] // 2:]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin):
    # q, k: [batch, n_heads, seq_len, head_dim]
    cos = cos.unsqueeze(1)  # [batch, 1, seq_len, dim]
    sin = sin.unsqueeze(1)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class RelativePositionBias(nn.Module):
    """可学习的相对位置偏置"""
    def __init__(self, num_heads, max_len=512):
        super().__init__()
        self.num_heads = num_heads
        self.max_len = max_len
        self.rel_pos_bias = nn.Parameter(torch.zeros(num_heads, 2 * max_len - 1))

    def forward(self, seq_len, device):
        positions = torch.arange(seq_len, device=device)
        rel_pos = positions.unsqueeze(1) - positions.unsqueeze(0)  # [seq, seq]
        rel_pos += self.max_len - 1  # 偏移到非负索引
        rel_pos = torch.clamp(rel_pos, 0, 2 * self.max_len - 2)
        return self.rel_pos_bias[:, rel_pos]  # [n_heads, seq, seq]


class DepthwiseSeparableFFN(nn.Module):
    """
    深度可分离前馈网络
    分解为：逐通道变换 -> 逐位置变换
    参数量从 2*d_model*d_ff 降低到 d_model*d_ff + d_model*2
    """
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.depthwise = nn.Linear(d_model, d_ff)
        self.pointwise = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()

        # 通道混合
        self.channel_mix = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, d_model),
        )

    def forward(self, x):
        # 逐通道扩展
        out = self.depthwise(x)
        out = self.activation(out)
        out = self.dropout(out)
        # 逐位置投影
        out = self.pointwise(out)
        # 残差式通道混合
        channel = self.channel_mix(x)
        return out + 0.1 * channel  # 小系数保证稳定性


class GatedFusion(nn.Module):
    """
    门控融合机制
    融合局部注意力和全局注意力的输出
    """
    def __init__(self, d_model):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.Sigmoid()
        )
        self.output_proj = nn.Linear(d_model, d_model)

    def forward(self, local_out, global_out):
        """
        local_out: 局部注意力输出
        global_out: 全局注意力输出
        """
        concat = torch.cat([local_out, global_out], dim=-1)
        gate = self.gate(concat)  # [batch, seq, d_model]
        fused = gate * local_out + (1 - gate) * global_out
        return self.output_proj(fused)


class HierarchicalMultiHeadAttention(nn.Module):
    """
    层次化多头注意力机制
    - 低层头：局部窗口注意力（窗口大小 w）
    - 高层头：全局注意力
    """
    def __init__(self, d_model, n_heads, dropout=0.1, local_ratio=0.5, window_size=32):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.n_local_heads = int(n_heads * local_ratio)
        self.n_global_heads = n_heads - self.n_local_heads
        self.window_size = window_size

        # 统一投影
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)

        # 局部和全局的输出投影
        self.out_proj_local = nn.Linear(self.n_local_heads * self.head_dim, d_model)
        self.out_proj_global = nn.Linear(self.n_global_heads * self.head_dim, d_model)

        self.dropout = nn.Dropout(dropout)

        # 相对位置偏置
        self.rel_pos_bias = RelativePositionBias(self.n_local_heads + self.n_global_heads)
        self.rope = RotaryPositionalEmbedding(self.head_dim)

        # 门控融合
        self.gated_fusion = GatedFusion(d_model)

        self.scale = self.head_dim ** -0.5

    def _local_attention(self, q, k, v, mask=None):
        """窗口局部注意力"""
        batch, n_heads, seq_len, head_dim = q.shape
        w = min(self.window_size, seq_len)

        # 零填充使seq_len可被窗口大小整除（近似）
        # 这里使用简化实现：通过注意力掩码实现局部性
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        # 局部窗口掩码
        window_mask = torch.zeros(seq_len, seq_len, device=q.device)
        for i in range(seq_len):
            left = max(0, i - w // 2)
            right = min(seq_len, i + w // 2 + 1)
            window_mask[i, left:right] = 1.0
        window_mask = window_mask.unsqueeze(0).unsqueeze(0)  # [1, 1, seq, seq]
        attn_scores = attn_scores.masked_fill(window_mask == 0, float('-inf'))

        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        return torch.matmul(attn_weights, v)

    def _global_attention(self, q, k, v, mask=None):
        """全局注意力"""
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale

        # 添加相对位置偏置
        seq_len = q.shape[2]
        rel_bias = self.rel_pos_bias(seq_len, q.device)
        # 取后半部分头（全局头）的偏置，简化实现用全部偏置的平均
        attn_scores = attn_scores + rel_bias.mean(0, keepdim=True).unsqueeze(0)

        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        return torch.matmul(attn_weights, v)

    def forward(self, x, mask=None):
        batch, seq_len, _ = x.shape

        q = self.q_proj(x).view(batch, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch, seq_len, self.n_heads, self.head_dim).transpose(1, 2)

        # RoPE
        cos, sin = self.rope(x)
        q, k = apply_rotary_pos_emb(q, k, cos, sin)

        # 分离局部和全局头
        q_local, q_global = q[:, :self.n_local_heads], q[:, self.n_local_heads:]
        k_local, k_global = k[:, :self.n_local_heads], k[:, self.n_local_heads:]
        v_local, v_global = v[:, :self.n_local_heads], v[:, self.n_local_heads:]

        # 局部注意力
        local_out = self._local_attention(q_local, k_local, v_local, mask)
        local_out = local_out.transpose(1, 2).contiguous().view(batch, seq_len, -1)
        local_out = self.out_proj_local(local_out)

        # 全局注意力
        global_out = self._global_attention(q_global, k_global, v_global, mask)
        global_out = global_out.transpose(1, 2).contiguous().view(batch, seq_len, -1)
        global_out = self.out_proj_global(global_out)

        # 门控融合
        output = self.gated_fusion(local_out, global_out)

        return output


class HATEncoderLayer(nn.Module):
    """改进的编码器层"""
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1, local_ratio=0.5, window_size=32):
        super().__init__()
        self.self_attn = HierarchicalMultiHeadAttention(
            d_model, n_heads, dropout, local_ratio, window_size
        )
        self.ffn = DepthwiseSeparableFFN(d_model, d_ff, dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        # Pre-LN 结构（更稳定的训练）
        attn_out = self.self_attn(self.norm1(x), mask)
        x = x + self.dropout(attn_out)
        ffn_out = self.ffn(self.norm2(x))
        x = x + self.dropout(ffn_out)
        return x


class HATDecoderLayer(nn.Module):
    """改进的解码器层"""
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1, local_ratio=0.5, window_size=32):
        super().__init__()
        self.self_attn = HierarchicalMultiHeadAttention(
            d_model, n_heads, dropout, local_ratio, window_size
        )
        self.cross_attn = HierarchicalMultiHeadAttention(
            d_model, n_heads, dropout, local_ratio, window_size
        )
        self.ffn = DepthwiseSeparableFFN(d_model, d_ff, dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, enc_out, src_mask=None, tgt_mask=None):
        # 自注意力
        attn_out = self.self_attn(self.norm1(x), tgt_mask)
        x = x + self.dropout(attn_out)

        # 交叉注意力
        # 简化：将编码器输出作为额外的key/value，这里使用标准实现
        batch, tgt_len, d_model = x.shape
        n_heads = self.cross_attn.n_heads
        head_dim = self.cross_attn.head_dim

        x_norm = self.norm2(x)
        q = self.cross_attn.q_proj(x_norm).view(batch, tgt_len, n_heads, head_dim).transpose(1, 2)
        k = self.cross_attn.k_proj(enc_out).view(batch, -1, n_heads, head_dim).transpose(1, 2)
        v = self.cross_attn.v_proj(enc_out).view(batch, -1, n_heads, head_dim).transpose(1, 2)

        # 分离头
        q_l, q_g = q[:, :self.cross_attn.n_local_heads], q[:, self.cross_attn.n_local_heads:]
        k_l, k_g = k[:, :self.cross_attn.n_local_heads], k[:, self.cross_attn.n_local_heads:]
        v_l, v_g = v[:, :self.cross_attn.n_local_heads], v[:, self.cross_attn.n_local_heads:]

        scale = head_dim ** -0.5

        # 局部交叉注意力
        attn_l = torch.matmul(q_l, k_l.transpose(-2, -1)) * scale
        if src_mask is not None:
            attn_l = attn_l.masked_fill(src_mask.unsqueeze(1).unsqueeze(2) == 0, float('-inf'))
        attn_l = F.softmax(attn_l, dim=-1)
        local_out = torch.matmul(attn_l, v_l).transpose(1, 2).contiguous().view(batch, tgt_len, -1)

        # 全局交叉注意力
        attn_g = torch.matmul(q_g, k_g.transpose(-2, -1)) * scale
        if src_mask is not None:
            attn_g = attn_g.masked_fill(src_mask.unsqueeze(1).unsqueeze(2) == 0, float('-inf'))
        attn_g = F.softmax(attn_g, dim=-1)
        global_out = torch.matmul(attn_g, v_g).transpose(1, 2).contiguous().view(batch, tgt_len, -1)

        # 投影
        local_proj = self.cross_attn.out_proj_local(local_out)
        global_proj = self.cross_attn.out_proj_global(global_out)

        # 门控融合
        cross_out = self.cross_attn.gated_fusion(local_proj, global_proj)
        x = x + self.dropout(cross_out)

        # FFN
        ffn_out = self.ffn(self.norm3(x))
        x = x + self.dropout(ffn_out)

        return x


class HATTransformer(nn.Module):
    """
    层次化注意力Transformer (HAT) 翻译模型
    """
    def __init__(
        self,
        src_vocab_size,
        tgt_vocab_size,
        d_model=512,
        n_heads=8,
        n_encoder_layers=6,
        n_decoder_layers=6,
        d_ff=2048,
        dropout=0.1,
        local_ratio=0.5,
        window_size=32,
        max_seq_len=512,
        pad_idx=0,
    ):
        super().__init__()
        self.d_model = d_model
        self.pad_idx = pad_idx

        # 词嵌入
        self.src_embed = nn.Embedding(src_vocab_size, d_model, padding_idx=pad_idx)
        self.tgt_embed = nn.Embedding(tgt_vocab_size, d_model, padding_idx=pad_idx)

        # 位置编码（作为可学习偏置初始化）
        self.src_pos_embed = nn.Parameter(torch.zeros(1, max_seq_len, d_model))
        self.tgt_pos_embed = nn.Parameter(torch.zeros(1, max_seq_len, d_model))
        nn.init.normal_(self.src_pos_embed, mean=0, std=0.02)
        nn.init.normal_(self.tgt_pos_embed, mean=0, std=0.02)

        self.dropout = nn.Dropout(dropout)

        # 编码器
        self.encoder_layers = nn.ModuleList([
            HATEncoderLayer(d_model, n_heads, d_ff, dropout, local_ratio, window_size)
            for _ in range(n_encoder_layers)
        ])

        # 解码器
        self.decoder_layers = nn.ModuleList([
            HATDecoderLayer(d_model, n_heads, d_ff, dropout, local_ratio, window_size)
            for _ in range(n_decoder_layers)
        ])

        # 最终归一化
        self.enc_norm = nn.LayerNorm(d_model)
        self.dec_norm = nn.LayerNorm(d_model)

        # 输出投影
        self.output_proj = nn.Linear(d_model, tgt_vocab_size)

        # 权重绑定（输入嵌入与输出投影共享权重）
        self.output_proj.weight = self.tgt_embed.weight

        # 参数初始化
        self._init_params()

    def _init_params(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def encode(self, src_ids, src_mask=None):
        # 词嵌入 + 位置嵌入
        x = self.src_embed(src_ids) * math.sqrt(self.d_model)
        x = x + self.src_pos_embed[:, :x.shape[1], :]
        x = self.dropout(x)

        # 通过编码器层
        for layer in self.encoder_layers:
            x = layer(x, src_mask)
        x = self.enc_norm(x)
        return x

    def decode(self, tgt_ids, enc_out, src_mask=None, tgt_mask=None):
        x = self.tgt_embed(tgt_ids) * math.sqrt(self.d_model)
        x = x + self.tgt_pos_embed[:, :x.shape[1], :]
        x = self.dropout(x)

        for layer in self.decoder_layers:
            x = layer(x, enc_out, src_mask, tgt_mask)
        x = self.dec_norm(x)
        return self.output_proj(x)

    def forward(self, src_ids, tgt_ids, src_mask=None, tgt_mask=None):
        enc_out = self.encode(src_ids, src_mask)
        logits = self.decode(tgt_ids, enc_out, src_mask, tgt_mask)
        return logits

    def generate(self, src_ids, max_len=128, bos_id=1, eos_id=2, src_mask=None):
        """贪心解码"""
        self.eval()
        enc_out = self.encode(src_ids, src_mask)
        batch = src_ids.shape[0]

        generated = torch.full((batch, 1), bos_id, dtype=torch.long, device=src_ids.device)

        for _ in range(max_len):
            tgt_mask = self._causal_mask(generated.shape[1], generated.device)
            logits = self.decode(generated, enc_out, src_mask, tgt_mask)
            next_token = logits[:, -1:, :].argmax(dim=-1)
            generated = torch.cat([generated, next_token], dim=1)

            if (next_token == eos_id).all():
                break

        return generated

    def generate_beam(self, src_ids, max_len=128, bos_id=1, eos_id=2, beam_size=5, src_mask=None):
        """束搜索解码"""
        self.eval()
        enc_out = self.encode(src_ids, src_mask)
        batch = src_ids.shape[0]
        device = src_ids.device

        # 扩展编码器输出到beam维度
        enc_out = enc_out.unsqueeze(1).repeat(1, beam_size, 1, 1).view(batch * beam_size, -1, self.d_model)
        if src_mask is not None:
            src_mask = src_mask.unsqueeze(1).repeat(1, beam_size, 1, 1).view(batch * beam_size, 1, 1, -1)

        # 初始化beam
        scores = torch.zeros(batch, beam_size, device=device)
        scores[:, 1:] = -1e9  # 只有第一个beam有效
        sequences = torch.full((batch, beam_size, 1), bos_id, dtype=torch.long, device=device)
        done = torch.zeros(batch, beam_size, dtype=torch.bool, device=device)

        for step in range(max_len):
            curr_seq = sequences.view(batch * beam_size, -1)
            tgt_mask = self._causal_mask(curr_seq.shape[1], device)

            logits = self.decode(curr_seq, enc_out, src_mask, tgt_mask)
            log_probs = F.log_softmax(logits[:, -1, :], dim=-1)  # [batch*beam, vocab]

            # 加上累计分数
            log_probs = log_probs.view(batch, beam_size, -1)
            log_probs = log_probs + scores.unsqueeze(-1)

            # 将已完成的beam分数设低
            if done.any():
                log_probs[done] = -1e9

            # 选择top-k
            if step == 0:
                log_probs = log_probs[:, 0:1, :]  # 只在第一个beam上扩展

            flat_scores, flat_idx = log_probs.view(batch, -1).topk(beam_size, dim=-1)

            scores = flat_scores
            beam_idx = flat_idx // log_probs.shape[-1]  # 来自哪个beam
            token_idx = flat_idx % log_probs.shape[-1]  # 选择的token

            # 更新序列
            new_sequences = torch.zeros(batch, beam_size, step + 2, dtype=torch.long, device=device)
            for b in range(batch):
                for i in range(beam_size):
                    prev_beam = beam_idx[b, i]
                    prev_seq = sequences[b, prev_beam, :]
                    new_token = token_idx[b, i]
                    new_sequences[b, i, :step + 1] = prev_seq
                    new_sequences[b, i, step + 1] = new_token

            sequences = new_sequences

            # 更新完成状态
            for b in range(batch):
                for i in range(beam_size):
                    if token_idx[b, i] == eos_id:
                        done[b, i] = True

            if done.all():
                break

        # 选择得分最高的序列
        best = sequences[:, 0, :]
        return best

    @staticmethod
    def _causal_mask(seq_len, device):
        """因果掩码（下三角矩阵）"""
        mask = torch.tril(torch.ones(seq_len, seq_len, device=device)).bool()
        return mask.unsqueeze(0).unsqueeze(0)  # [1, 1, seq, seq]

    @staticmethod
    def create_padding_mask(seq, pad_idx=0):
        """创建padding掩码"""
        return (seq != pad_idx).unsqueeze(1).unsqueeze(2)  # [batch, 1, 1, seq]
