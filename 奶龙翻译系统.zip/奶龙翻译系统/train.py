"""
训练脚本：基于100万中英平行语料训练HAT-Transformer翻译模型
"""
import os
import sys
import json
import argparse
import time
import math
import random

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import numpy as np

# 添加项目路径
PROJ_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJ_DIR)

from models.hat_transformer import HATTransformer
from utils.tokenizer import BilingualTokenizer, train_tokenizer


# ============ 配置 ============
class Config:
    # 数据
    data_dir = os.path.join(PROJ_DIR, "data", "processed")
    model_dir = os.path.join(PROJ_DIR, "models")
    result_dir = os.path.join(PROJ_DIR, "results")

    # 模型
    d_model = 512
    n_heads = 8
    n_encoder_layers = 6
    n_decoder_layers = 6
    d_ff = 2048
    dropout = 0.1
    local_ratio = 0.5
    window_size = 32
    max_seq_len = 128
    vocab_size = 32000

    # 训练
    batch_size = 64
    gradient_accumulation = 4  # 实际batch_size = 64 * 4 = 256
    epochs = 30
    warmup_steps = 4000
    learning_rate = 1e-4
    min_lr = 1e-6
    weight_decay = 0.01
    label_smoothing = 0.1
    max_grad_norm = 1.0

    # 系统
    device = "cuda" if torch.cuda.is_available() else "cpu"
    num_workers = 4
    seed = 42
    save_every = 2
    log_every = 100
    eval_every = 1000

    # 混合精度
    use_amp = True if device == "cuda" else False


class TranslationDataset(Dataset):
    """翻译数据集"""

    def __init__(self, src_file, tgt_file, tokenizer, max_len=128):
        self.tokenizer = tokenizer
        self.max_len = max_len
        self.pairs = []

        with open(src_file, "r", encoding="utf-8") as f_src, \
             open(tgt_file, "r", encoding="utf-8") as f_tgt:
            for src, tgt in zip(f_src, f_tgt):
                src = src.strip()
                tgt = tgt.strip()
                if src and tgt:
                    self.pairs.append((src, tgt))

        print(f"Loaded {len(self.pairs)} translation pairs")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        src_text, tgt_text = self.pairs[idx]

        # 编码
        src_ids = self.tokenizer.encode(src_text, max_len=self.max_len, add_bos=True, add_eos=True)
        tgt_ids = self.tokenizer.encode(tgt_text, max_len=self.max_len, add_bos=True, add_eos=True)

        return {
            "src_ids": torch.tensor(src_ids, dtype=torch.long),
            "tgt_ids": torch.tensor(tgt_ids, dtype=torch.long),
            "src_len": len(src_ids),
            "tgt_len": len(tgt_ids),
        }


def collate_fn(batch, pad_id=0):
    """批次整理"""
    src_max = max(item["src_len"] for item in batch)
    tgt_max = max(item["tgt_len"] for item in batch)

    batch_size = len(batch)
    src_padded = torch.full((batch_size, src_max), pad_id, dtype=torch.long)
    tgt_padded = torch.full((batch_size, tgt_max), pad_id, dtype=torch.long)
    src_mask = torch.zeros(batch_size, src_max, dtype=torch.bool)
    tgt_mask = torch.zeros(batch_size, tgt_max, dtype=torch.bool)

    for i, item in enumerate(batch):
        src_len = item["src_len"]
        tgt_len = item["tgt_len"]
        src_padded[i, :src_len] = item["src_ids"]
        tgt_padded[i, :tgt_len] = item["tgt_ids"]
        src_mask[i, :src_len] = True
        tgt_mask[i, :tgt_len] = True

    return {
        "src_ids": src_padded,
        "tgt_ids": tgt_padded,
        "src_mask": src_mask,
        "tgt_mask": tgt_mask,
    }


class LabelSmoothingLoss(nn.Module):
    """标签平滑交叉熵"""

    def __init__(self, smoothing=0.1, ignore_index=0):
        super().__init__()
        self.smoothing = smoothing
        self.ignore_index = ignore_index
        self.confidence = 1.0 - smoothing

    def forward(self, logits, target):
        """
        logits: [batch * seq, vocab]
        target: [batch * seq]
        """
        vocab = logits.shape[-1]
        log_probs = F.log_softmax(logits, dim=-1)

        with torch.no_grad():
            true_dist = torch.zeros_like(log_probs)
            true_dist.fill_(self.smoothing / (vocab - 1))
            true_dist.scatter_(1, target.unsqueeze(1), self.confidence)
            true_dist[:, self.ignore_index] = 0
            mask = (target == self.ignore_index).unsqueeze(1)
            true_dist.masked_fill_(mask, 0)

        loss = -(true_dist * log_probs).sum(dim=-1)
        # 僅对非ignore_index的位置计算loss
        valid = (target != self.ignore_index).float()
        loss = (loss * valid).sum() / valid.sum().clamp(min=1)
        return loss


class Trainer:
    """训练器"""

    def __init__(self, config, tokenizer):
        self.config = config
        self.tokenizer = tokenizer
        self.device = torch.device(config.device)

        # 数据集
        self.train_dataset = TranslationDataset(
            os.path.join(config.data_dir, "train.en"),
            os.path.join(config.data_dir, "train.zh"),
            tokenizer,
            config.max_seq_len,
        )
        self.valid_dataset = TranslationDataset(
            os.path.join(config.data_dir, "valid.en"),
            os.path.join(config.data_dir, "valid.zh"),
            tokenizer,
            config.max_seq_len,
        )

        self.train_loader = DataLoader(
            self.train_dataset,
            batch_size=config.batch_size,
            shuffle=True,
            num_workers=config.num_workers,
            collate_fn=collate_fn,
            pin_memory=True,
            drop_last=True,
        )
        self.valid_loader = DataLoader(
            self.valid_dataset,
            batch_size=config.batch_size,
            shuffle=False,
            num_workers=config.num_workers,
            collate_fn=collate_fn,
            pin_memory=True,
        )

        # 模型
        vocab_size = tokenizer.vocab_size
        self.model = HATTransformer(
            src_vocab_size=vocab_size,
            tgt_vocab_size=vocab_size,
            d_model=config.d_model,
            n_heads=config.n_heads,
            n_encoder_layers=config.n_encoder_layers,
            n_decoder_layers=config.n_decoder_layers,
            d_ff=config.d_ff,
            dropout=config.dropout,
            local_ratio=config.local_ratio,
            window_size=config.window_size,
            max_seq_len=config.max_seq_len,
            pad_idx=tokenizer.special_tokens["PAD"],
        )
        self.model = self.model.to(self.device)

        # 损失函数
        self.criterion = LabelSmoothingLoss(
            smoothing=config.label_smoothing,
            ignore_index=tokenizer.special_tokens["PAD"],
        )

        # 优化器
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=config.learning_rate,
            betas=(0.9, 0.98),
            eps=1e-9,
            weight_decay=config.weight_decay,
        )

        # 学习率调度器（带预热余弦退火）
        self.scheduler = CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=config.epochs * len(self.train_loader) // 2,
            T_mult=2,
            eta_min=config.min_lr,
        )

        # 混合精度
        self.scaler = torch.cuda.amp.GradScaler(enabled=config.use_amp)

        # 训练状态
        self.global_step = 0
        self.best_valid_loss = float("inf")
        self.epoch = 0

        # 日志
        os.makedirs(config.result_dir, exist_ok=True)
        self.log_file = os.path.join(config.result_dir, "training_log.jsonl")
        self.metrics_history = []

        # 模型统计
        n_params = sum(p.numel() for p in self.model.parameters())
        n_trainable = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Model parameters: {n_params:,} total, {n_trainable:,} trainable")

    def get_lr(self):
        """预热学习率"""
        step = max(1, self.global_step)
        warmup = self.config.warmup_steps
        lr = self.config.learning_rate * min(step ** -0.5, step * warmup ** -1.5)
        lr = max(lr, self.config.min_lr)
        return lr

    def train_step(self, batch):
        """单步训练"""
        self.model.train()

        src_ids = batch["src_ids"].to(self.device)
        tgt_ids = batch["tgt_ids"].to(self.device)

        # 创建掩码
        src_mask = (src_ids != self.tokenizer.special_tokens["PAD"]).bool().unsqueeze(1).unsqueeze(2)
        tgt_mask = self.model._causal_mask(tgt_ids.shape[1] - 1, self.device)

        # 解码器输入去掉最后一个token，目标去掉第一个token
        tgt_input = tgt_ids[:, :-1]
        tgt_target = tgt_ids[:, 1:]

        with torch.cuda.amp.autocast(enabled=self.config.use_amp):
            logits = self.model(src_ids, tgt_input, src_mask, tgt_mask)
            loss = self.criterion(
                logits.contiguous().view(-1, logits.shape[-1]),
                tgt_target.contiguous().view(-1),
            )

        # 梯度累积
        loss = loss / self.config.gradient_accumulation

        self.scaler.scale(loss).backward()

        if (self.global_step + 1) % self.config.gradient_accumulation == 0:
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)

            # 手动设置学习率（预热阶段）
            if self.global_step < self.config.warmup_steps:
                lr = self.get_lr()
                for param_group in self.optimizer.param_groups:
                    param_group["lr"] = lr

            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad()

        self.global_step += 1
        return loss.item() * self.config.gradient_accumulation

    @torch.no_grad()
    def evaluate(self):
        """验证"""
        self.model.eval()
        total_loss = 0
        total_tokens = 0

        for batch in self.valid_loader:
            src_ids = batch["src_ids"].to(self.device)
            tgt_ids = batch["tgt_ids"].to(self.device)

            src_mask = (src_ids != self.tokenizer.special_tokens["PAD"]).bool().unsqueeze(1).unsqueeze(2)
            tgt_mask = self.model._causal_mask(tgt_ids.shape[1] - 1, self.device)

            tgt_input = tgt_ids[:, :-1]
            tgt_target = tgt_ids[:, 1:]

            logits = self.model(src_ids, tgt_input, src_mask, tgt_mask)
            loss = self.criterion(
                logits.contiguous().view(-1, logits.shape[-1]),
                tgt_target.contiguous().view(-1),
            )

            # 计算非padding token数量
            n_tokens = (tgt_target != self.tokenizer.special_tokens["PAD"]).sum().item()
            total_loss += loss.item() * n_tokens
            total_tokens += n_tokens

        avg_loss = total_loss / max(total_tokens, 1)
        perplexity = math.exp(min(avg_loss, 20))
        return avg_loss, perplexity

    @torch.no_grad()
    def compute_bleu(self, num_samples=200):
        """计算BLEU分数（简化版本）"""
        self.model.eval()
        bos = self.tokenizer.special_tokens["BOS"]
        eos = self.tokenizer.special_tokens["EOS"]

        references = []
        hypotheses = []

        for i in range(min(num_samples, len(self.valid_dataset))):
            item = self.valid_dataset[i]
            src_ids = item["src_ids"].unsqueeze(0).to(self.device)

            # 生成翻译
            pred_ids = self.model.generate(
                src_ids,
                max_len=self.config.max_seq_len,
                bos_id=bos,
                eos_id=eos,
            )

            # 解码
            ref_text = self.tokenizer.decode(item["tgt_ids"].tolist(), skip_special=True)
            hyp_text = self.tokenizer.decode(pred_ids[0].tolist(), skip_special=True)

            references.append([ref_text.split()])
            hypotheses.append(hyp_text.split())

        # 简化BLEU（实际可以用 sacrebleu）
        if len(hypotheses[0]) == 0:
            return 0.0

        # n-gram匹配计算
        def ngrams(tokens, n):
            return set(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))

        bleu_scores = []
        for hyp, refs in zip(hypotheses, references):
            ref = refs[0]
            if len(hyp) < 4 or len(ref) < 4:
                bleu_scores.append(0)
                continue

            precisions = []
            for n in range(1, 5):
                hyp_ngrams = ngrams(hyp, n)
                ref_ngrams = ngrams(ref, n)
                if len(hyp_ngrams) == 0:
                    precisions.append(0)
                else:
                    matches = len(hyp_ngrams & ref_ngrams)
                    precisions.append(matches / len(hyp_ngrams))

            if min(precisions) == 0:
                bleu_scores.append(0)
                continue

            # 简洁惩罚
            bp = min(1, math.exp(1 - len(ref) / max(len(hyp), 1)))
            bleu = bp * math.exp(sum(math.log(max(p, 1e-10)) for p in precisions) / 4)
            bleu_scores.append(bleu)

        return np.mean(bleu_scores) * 100

    def save_checkpoint(self, path, is_best=False):
        """保存检查点"""
        checkpoint = {
            "epoch": self.epoch,
            "global_step": self.global_step,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "scaler_state_dict": self.scaler.state_dict(),
            "best_valid_loss": self.best_valid_loss,
            "config": self.config.__dict__,
        }
        torch.save(checkpoint, path)
        if is_best:
            best_path = path.replace(".pt", "_best.pt")
            torch.save(checkpoint, best_path)
            print(f"  Best model saved to {best_path}")

    def train(self):
        """主训练循环"""
        print(f"\n{'='*60}")
        print(f"Starting training on {self.config.device}")
        print(f"Train samples: {len(self.train_dataset)}")
        print(f"Valid samples: {len(self.valid_dataset)}")
        print(f"Batch size: {self.config.batch_size} x {self.config.gradient_accumulation} = "
              f"{self.config.batch_size * self.config.gradient_accumulation}")
        print(f"Model: HAT-Transformer")
        print(f"d_model={self.config.d_model}, n_heads={self.config.n_heads}, "
              f"layers={self.config.n_encoder_layers}E-{self.config.n_decoder_layers}D")
        print(f"{'='*60}\n")

        for epoch in range(self.config.epochs):
            self.epoch = epoch
            epoch_loss = 0
            epoch_start = time.time()

            for i, batch in enumerate(self.train_loader):
                loss = self.train_step(batch)
                epoch_loss += loss

                if self.global_step % self.config.log_every == 0:
                    lr = self.optimizer.param_groups[0]["lr"]
                    print(f"  Step {self.global_step:7d} | Loss: {loss:.4f} | LR: {lr:.2e}")

                if self.global_step % self.config.eval_every == 0 and self.global_step > 0:
                    val_loss, ppl = self.evaluate()
                    bleu = self.compute_bleu(num_samples=100)
                    print(f"  [Eval] Step {self.global_step} | Val Loss: {val_loss:.4f} | "
                          f"PPL: {ppl:.2f} | BLEU: {bleu:.2f}")

                    self.metrics_history.append({
                        "step": self.global_step,
                        "epoch": epoch,
                        "train_loss": epoch_loss / (i + 1),
                        "val_loss": val_loss,
                        "perplexity": ppl,
                        "bleu": bleu,
                    })

                    # 保存日志
                    with open(self.log_file, "a", encoding="utf-8") as f:
                        f.write(json.dumps(self.metrics_history[-1]) + "\n")

            # Epoch结束
            epoch_time = time.time() - epoch_start
            avg_loss = epoch_loss / len(self.train_loader)
            val_loss, ppl = self.evaluate()
            bleu = self.compute_bleu(num_samples=200)

            print(f"\n{'='*60}")
            print(f"Epoch {epoch + 1}/{self.config.epochs} completed in {epoch_time:.1f}s")
            print(f"  Train Loss: {avg_loss:.4f}")
            print(f"  Valid Loss: {val_loss:.4f} | PPL: {ppl:.2f} | BLEU: {bleu:.2f}")
            print(f"{'='*60}\n")

            # 保存检查点
            if (epoch + 1) % self.config.save_every == 0 or epoch == self.config.epochs - 1:
                ckpt_path = os.path.join(self.config.result_dir, f"checkpoint_epoch{epoch + 1}.pt")
                is_best = val_loss < self.best_valid_loss
                if is_best:
                    self.best_valid_loss = val_loss
                self.save_checkpoint(ckpt_path, is_best)

            # 更新学习率（预热后）
            if self.global_step >= self.config.warmup_steps:
                self.scheduler.step()

        print("\n" + "=" * 60)
        print("Training complete!")
        print(f"Best validation loss: {self.best_valid_loss:.4f}")
        print(f"Results saved to: {self.config.result_dir}")
        print("=" * 60)


def main():
    torch.manual_seed(Config.seed)
    np.random.seed(Config.seed)
    random.seed(Config.seed)

    # 检查数据是否存在
    train_en = os.path.join(Config.data_dir, "train.en")
    if not os.path.exists(train_en):
        print("Dataset not found. Running data preparation...")
        sys.path.insert(0, os.path.join(PROJ_DIR, "data"))
        from prepare_dataset import generate_million_parallel_corpus
        generate_million_parallel_corpus()

    # 检查分词器是否存在
    tokenizer_path = os.path.join(Config.model_dir, "bpe_tokenizer.model")
    if not os.path.exists(tokenizer_path):
        print("Tokenizer not found. Training tokenizer...")
        tokenizer_path = train_tokenizer(os.path.join(PROJ_DIR, "data"), Config.model_dir)

    # 加载分词器
    tokenizer = BilingualTokenizer(tokenizer_path)
    print(f"Tokenizer loaded. Vocab size: {tokenizer.vocab_size}")

    # 创建训练器并开始训练
    trainer = Trainer(Config, tokenizer)
    trainer.train()


if __name__ == "__main__":
    main()
